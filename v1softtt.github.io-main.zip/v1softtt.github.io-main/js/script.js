// Появление сообщений
let card2 = document.querySelector(".screen-one__card2", ".btn");
card2.addEventListener("animationend", function () {
  card2.classList.add("visible");
});

